# se206_ass3
This is a java applet which helps to record audio, playback, and practise names in general. 
Multiple reocrdings of a single name can be quickly and easily viewed, and a small prompt ensures that the user knows when a bad Recording is present.
![](demo.gif)
